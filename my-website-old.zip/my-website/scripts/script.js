const blob = document.getElementById("blob");

function getScrollHeight() {
  return Math.max(
    document.body.scrollTop,
    document.documentElement.scrollTop
  );
}

window.onpointermove = event => {
  const { clientX, clientY } = event;

  blob.animate({
    left: `${clientX}px`,
    top: `${clientY * 0.7 + getScrollHeight() * 0.7}px`
  }, { duration: 3000, fill: "forwards" });
}

window.onscroll = function () {
  if (document.body.scrollTop > 50 || document.documentElement.scrollTop > 50) {
    document.getElementById("header").style.backgroundColor = "#333";
  } else {
    document.getElementById("header").style.backgroundColor = "transparent";
  }
};

const rand = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

const enhance = id => {
  const element = document.getElementById(id),
    text = element.innerText.split("");

  element.innerText = "";

  text.forEach((value, index) => {
    const outer = document.createElement("span");
    outer.className = "outer";
    const inner = document.createElement("span");
    inner.className = "inner";
    inner.style.animationDelay = `${rand(-5000, 0)}ms`;
    const letter = document.createElement("span");
    letter.className = "letter";
    letter.innerText = value;
    letter.style.animationDelay = `${index * 1000}ms`;
    inner.appendChild(letter);
    outer.appendChild(inner);
    element.appendChild(outer);
  });
}

enhance("channel-link");

let index = 0,
  interval = 1000;

const rando = (min, max) =>
  Math.floor(Math.random() * (max - min + 1)) + min;

const animate = star => {
  star.style.setProperty("--star-left", `${rando(-10, 100)}%`);
  star.style.setProperty("--star-top", `${rando(-40, 80)}%`);

  star.style.animation = "none";
  star.offsetHeight;
  star.style.animation = "";
}

for (const star of document.getElementsByClassName("magic-star")) {
  setTimeout(() => {
    animate(star);

    setInterval(() => animate(star), 1000);
  }, index++ * (interval / 3))
}

window.onload = function () {
  fetch('texts/about-me.txt')
    .then(response => response.text())
    .then(data => {
      document.getElementById('aboutMeParagraph').innerText = data;
    })
    .catch(error => console.error('Error fetching text file:', error));
};

//YouTube Subscriber Counter
const aPIKey = "AIzaSyCf900dC4I_UfYoQrDjVPvcVy-CmH9UHbk";
const youtubeID = "UCqPhvVSUJDyc6Q7BfvodcoQ";
const subscriberCount = document.querySelector(".subscriber-count-number");
const viewCount = document.querySelector(".view-count-number");
const videoCount = document.querySelector(".video-count-number");
const getYoutubeSubscribers = async () => {
  const getData = await axios.get(
    `https://www.googleapis.com/youtube/v3/channels?part=statistics&id=${youtubeID}&key=${aPIKey}`
  );
  console.log(getData);
  console.log(getData.data.items[0].statistics);
  const youtubeSubscribers = getData.data.items[0].statistics.subscriberCount;
  const youtubeViews = getData.data.items[0].statistics.viewCount;
  const youtubeVideos = getData.data.items[0].statistics.videoCount;
  subscriberCount.innerHTML = youtubeSubscribers;
  viewCount.innerHTML = youtubeViews;
  videoCount.innerHTML = youtubeVideos;
};
getYoutubeSubscribers();

//Load Header And Footer
$(function () {
  $("#header").load("common-html/header.html");
  $("#footer").load("common-html/footer.html");
});